School Management System project using C# & ASP.NET Core MVC Pattern
